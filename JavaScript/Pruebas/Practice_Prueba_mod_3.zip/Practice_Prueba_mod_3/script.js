const routes = {
    "/":"./main.html",
    "/main": "./main.html",
    "/acerca": "./acerca.html",
    "/libros": "./books.html",
    "/inicioVisitante": "./inicioVisitante.html",
    "/inicioBibliotecario": "./inicioBibliotecario.html"

}
document.body.addEventListener("click", (e) =>{
    if( e.target.matches("[data-link]")) {
        e.preventDefault();
        navigate(e.target.getAttribute("href"))

    }
});
async function navigate(pathname){
    const route = routes[pathname]
    console.log(route)
    const html = await fetch(route).then(res => res.text())
    document.getElementById("content").innerHTML =html
}